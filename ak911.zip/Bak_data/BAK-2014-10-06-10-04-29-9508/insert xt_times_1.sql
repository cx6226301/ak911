-- 表的数据: xt_times --
INSERT INTO `xt_times` VALUES ('97','1412611199','1262275200','0','0','0','0');-- <fen> --
