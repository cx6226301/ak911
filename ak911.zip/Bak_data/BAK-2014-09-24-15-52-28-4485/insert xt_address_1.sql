-- 表的数据: xt_address --
INSERT INTO `xt_address` VALUES ('1','1','尼玛','北京市','13899999999','0');-- <fen> --
