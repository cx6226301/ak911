-- 表的数据: xt_plan --
INSERT INTO `xt_plan` VALUES ('1','<P>奖励计划</P>\r\n<P>\r\n<HR>\r\n\r\n<P></P>\r\n<P>&nbsp;</P>');-- <fen> --
INSERT INTO `xt_plan` VALUES ('2','<p>客服QQ</p>\r\n<p>&nbsp;</p>\r\n<div style=\"margin:5px;\" align=\"right\">2011-12-20 14:26:04</div>');-- <fen> --
INSERT INTO `xt_plan` VALUES ('3','<p>创富亮点</p>');-- <fen> --
INSERT INTO `xt_plan` VALUES ('4','<p>金币中心申请说明：</p>\r\n<p><br />\r\n金币中心名单： </p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>');-- <fen> --
INSERT INTO `xt_plan` VALUES ('5','123123');-- <fen> --
