-- 表的数据: xt_cptype --
INSERT INTO `xt_cptype` VALUES ('1','家用电器','0','0','0','0');-- <fen> --
INSERT INTO `xt_cptype` VALUES ('2','食品','0','0','0','0');-- <fen> --
INSERT INTO `xt_cptype` VALUES ('3','生活用品','0','0','0','0');-- <fen> --
